//
//  ViewController.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtusername: UITextField!
    @IBOutlet weak var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnlogin(_ sender: UIButton) {
        
        if txtusername.text == "jass" && password.text == "jass"
        {
            performSegue(withIdentifier: "paybill", sender: self)
            
        } else {
            let alert = UIAlertController(title: "Wrong Credentials", message: "Enter valid Email and password.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
                //https://developer.apple.com/documentation/uikit/uialertcontroller//
            }))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    }
    



