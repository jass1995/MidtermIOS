//
//  BillDetailsViewController.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

protocol PassDataProtocol
{
    func setTotal(totalBill: Double)
}

class BillDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var txtcustomername: UILabel!
    
    
    @IBOutlet weak var txtgender: UILabel!
    
    @IBOutlet weak var txttotalbill: UILabel!
    var electricitybill : ElectricityBill!
    var delegate: PassDataProtocol?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
    if let bill = electricitybill
        {
            print(bill.customername!)
            calculateTotalBillAmount()
            
            self.txtcustomername.text = electricitybill.customername
            self.txtgender.text = electricitybill.gender?.rawValue
            self.txttotalbill.text = String(format: "Total: %.2f", electricitybill.totalbillamount!)
        }
    
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    private func calculateTotalBillAmount()
    {
        
        var totalBill = 0.0
        
        if(electricitybill?.unitconsumed)! <= 100
        {
            totalBill = Double((electricitybill?.unitconsumed)!) * 0.75
        }else if (electricitybill?.unitconsumed)! <= 250
        {
            totalBill = 75 + (Double((electricitybill?.unitconsumed)!) - 100) * 1.25
        }else if (electricitybill?.unitconsumed)! <= 450
        {
            totalBill = 262.2 + (Double((electricitybill?.unitconsumed)!) - 250) * 1.75
        }else
        {
            totalBill = 612.5 + (Double((electricitybill?.unitconsumed)!) - 450) * 2.25
        }
        electricitybill.totalbillamount = totalBill
        print(totalBill)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
