//
//  ElectricityBill.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

enum Gender : String
{
    case MALE = "MALE"
    case FEMALE = "FEMALE"
  
}

struct ElectricityBill
{
    var customerID: Int?
    var customername: String?
    var gender: Gender?
    var billdate : Date?
    var unitconsumed : Int?
    var totalbillamount: Double?
}
